# tomato-disease-prediction
This is a complete repository for building the tomato plant disease prediction model and it is also deployed using Flask.
Link to Dataset :  https://www.kaggle.com/datasets/kaustubhb999/tomatoleaf
